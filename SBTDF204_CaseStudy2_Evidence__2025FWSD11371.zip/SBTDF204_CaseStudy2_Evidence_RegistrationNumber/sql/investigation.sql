.headers on
.mode column

SELECT name
FROM sqlite_master
WHERE type = 'table'
ORDER BY name;

PRAGMA table_info(urls);
PRAGMA table_info(visits);
PRAGMA table_info(downloads);
PRAGMA table_info(downloads_url_chains);

SELECT
    v.id AS visit_id,
    u.id AS url_id,
    u.url,
    u.title,
    datetime(
        v.visit_time/1000000 +
        strftime('%s','1601-01-01'),
        'unixepoch'
    ) AS visit_utc,
    v.from_visit,
    v.transition,
    (v.transition & 255) AS transition_base,
    v.visit_duration/1000.0 AS duration_ms
FROM visits AS v
JOIN urls AS u
    ON v.url = u.id
ORDER BY v.visit_time;

SELECT *
FROM downloads
ORDER BY start_time;

SELECT *
FROM downloads_url_chains
ORDER BY id;
